<?php
    header ('Location:'.'views/Admin/home.php');
?>